using System.Security.Cryptography;
using System.Text.Json;
using LittleBloom.Data;
using LittleBloom.Models;
using Microsoft.EntityFrameworkCore;

namespace LittleBloom.Services;

public class GiftService(IDbContextFactory<AppDbContext> factory)
{
    public async Task<Gift> CreateAsync(BouquetState bouquet, string recipient, string sender, string message)
    {
        var gift = new Gift
        {
            // 12 random url-safe characters: unguessable, so the link stays private.
            Token = Convert.ToBase64String(RandomNumberGenerator.GetBytes(9)).Replace('+', '-').Replace('/', '_'),
            RecipientName = recipient.Trim(),
            SenderName = sender.Trim(),
            Message = message.Trim(),
            VaseId = bouquet.VaseId ?? "classic",
            FlowersJson = JsonSerializer.Serialize(bouquet.Flowers),
        };
        await using var db = await factory.CreateDbContextAsync();
        db.Gifts.Add(gift);
        await db.SaveChangesAsync();
        return gift;
    }

    public async Task<Gift?> GetByTokenAsync(string token)
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.Gifts.AsNoTracking().FirstOrDefaultAsync(g => g.Token == token);
    }
}
