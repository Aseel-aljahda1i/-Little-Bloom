namespace LittleBloom.Services;

/// <summary>Holds the bouquet being built for the current visitor session.</summary>
public class BouquetState
{
    public Dictionary<string, int> Flowers { get; } = new();
    public string? VaseId { get; set; }
    public int Total => Flowers.Values.Sum();

    public void Add(string flowerId) => Flowers[flowerId] = Flowers.GetValueOrDefault(flowerId) + 1;
    public int Count(string flowerId) => Flowers.GetValueOrDefault(flowerId);
    public void Reset() { Flowers.Clear(); VaseId = null; }
}
