using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace LittleBloom.Models;

public class Gift
{
    public int Id { get; set; }
    public string Token { get; set; } = "";
    public string RecipientName { get; set; } = "";
    public string SenderName { get; set; } = "";
    public string Message { get; set; } = "";
    public string VaseId { get; set; } = "classic";
    /// <summary>JSON dictionary of flower id to count.</summary>
    public string FlowersJson { get; set; } = "{}";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [NotMapped]
    public Dictionary<string, int> Flowers =>
        JsonSerializer.Deserialize<Dictionary<string, int>>(FlowersJson) ?? new();
}
