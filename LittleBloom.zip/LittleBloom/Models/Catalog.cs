namespace LittleBloom.Models;

/// <summary>A flower or vase offered in the carousels. Top = y position of the vase mouth on the 400x500 bouquet canvas.</summary>
public record CatalogItem(string Id, string Name, int Top = 300);

public static class Catalog
{
    public static readonly IReadOnlyList<CatalogItem> Flowers = new[]
    {
        new CatalogItem("rose", "Roses"),
        new CatalogItem("tulip", "Tulips"),
        new CatalogItem("daisy", "Daisies"),
        new CatalogItem("babys-breath", "Baby’s Breath"),
        new CatalogItem("lily", "Lilies"),
        new CatalogItem("sunflower", "Sunflowers"),
        new CatalogItem("lavender", "Lavender"),
        new CatalogItem("poppy", "Poppies"),
        new CatalogItem("hydrangea", "Hydrangeas"),
        new CatalogItem("cosmos", "Cosmos"),
    };

    public static readonly IReadOnlyList<CatalogItem> Vases = new[]
    {
        new CatalogItem("classic", "Classic Glass Vase", 300),
        new CatalogItem("round", "Round Glass Vase", 300),
        new CatalogItem("tall", "Tall Glass Vase", 250),
        new CatalogItem("vintage", "Vintage Glass Vase", 300),
        new CatalogItem("wavy", "Wavy Glass Vase", 300),
    };

    public static CatalogItem Vase(string? id) => Vases.FirstOrDefault(v => v.Id == id) ?? Vases[0];
}
