// JavaScript is only used for the clipboard, which Blazor cannot reach on its own.
window.littleBloom = {
  copy: async (text) => { try { await navigator.clipboard.writeText(text); } catch { /* clipboard blocked */ } }
};
