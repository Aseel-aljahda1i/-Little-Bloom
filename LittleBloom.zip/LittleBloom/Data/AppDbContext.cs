using LittleBloom.Models;
using Microsoft.EntityFrameworkCore;

namespace LittleBloom.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Gift> Gifts => Set<Gift>();

    protected override void OnModelCreating(ModelBuilder b) =>
        b.Entity<Gift>().HasIndex(g => g.Token).IsUnique();
}
