# Little Bloom
ASP.NET Core Blazor Web App (.NET 8, interactive server), EF Core + SQLite.

Run: open LittleBloom.csproj in Visual Studio 2022 and press F5 (or `dotnet run`).
The SQLite file `littlebloom.db` is created automatically on first start.
Flow: / -> /flowers -> /vases -> /preview (message + private link) -> /gift/{token}
